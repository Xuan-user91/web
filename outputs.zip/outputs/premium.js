/* Native scrolling, progressive enhancement, and reduced-motion fallbacks. */
(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const header = document.querySelector('.site-header');
  const links = [...document.querySelectorAll('[data-chapter-link]')];
  const chapters = links.map(link => ({link, section:document.getElementById(link.hash.slice(1))})).filter(item => item.section);
  const statement = document.querySelector('[data-reading-statement]');
  const phrases = statement ? [...statement.children] : [];
  const statementSection = statement?.closest('.precision-statement');
  const progress = header?.querySelector('.reading-progress');
  let scheduled = false, active = null;
  const clamp = value => Math.max(0, Math.min(1, value));
  function updateHeaderSize() {
    if (header) document.documentElement.style.setProperty('--header-offset', `${Math.ceil(header.getBoundingClientRect().height)}px`);
    requestDraw();
  }
  function draw() {
    scheduled = false;
    const height = innerHeight;
    const top = header?.getBoundingClientRect().height || 0;
    const distance = document.documentElement.scrollHeight - height;
    if (progress) progress.style.setProperty('--page-progress', String(distance > 0 ? clamp(scrollY/distance) : 0));
    header?.classList.toggle('is-scrolled', scrollY > 24);
    let current = null;
    for (const chapter of chapters) {
      if (chapter.section.getBoundingClientRect().top <= top + Math.min(height*.25,180)) current = chapter.link;
    }
    if (current !== active) {
      active = current;
      chapters.forEach(({link}) => {
        if (link === active) link.setAttribute('aria-current','true');
        else link.removeAttribute('aria-current');
      });
    }
    if (statement && !reduced.matches) {
      const rect = statementSection.getBoundingClientRect();
      if (rect.bottom >= 0 && rect.top <= height) {
        statementSection.classList.add('is-reading');
        const t = clamp((height*.82-rect.top) / Math.max(1, rect.height*.68));
        phrases.forEach((phrase,index) => phrase.classList.toggle('is-read', t >= index/phrases.length));
      }
    } else statementSection?.classList.remove('is-reading');
  }
  function requestDraw() {
    if (!scheduled) { scheduled = true; requestAnimationFrame(draw); }
  }
  // Content is fully visible without this script, and on first-screen entry.
  const selector = [
    'main>.section .section-heading', 'main>.section .editorial-intro>div',
    '.service-tile','.flagship-summary','.credential-card','.credentials-heading',
    '.service-detail>figure','.service-detail-copy','.process-grid','.checklist-grid',
    '.case-study','.case-card','.gallery-item','.milestones>article','.company-facts',
    '.client-list','.career-principles','.role-card','.assessment-contact',
    '.recruit-info','.credential-management','.photo-triptych>figure',
    '.people-panorama figure','.wide-photo figure','.footprint-coverage .section-heading',
    '.team-composition','.organization-list','.faq-layout>div:first-child',
    '.contact-banner .container'
  ].join(',');
  const targets = [...new Set(document.querySelectorAll(selector))].filter(node => !node.closest('.motion-story'));
  const reveal = node => {
    node.classList.remove('reveal-pending');
    node.classList.add('is-revealed');
  };
  let observer;
  if ('IntersectionObserver' in window && !reduced.matches) {
    observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) { reveal(entry.target); observer.unobserve(entry.target); }
      });
    }, {threshold:0,rootMargin:'0px 0px -35px 0px'});
    targets.forEach((node,index) => {
      const box = node.getBoundingClientRect();
      if (box.top < innerHeight - 24 && box.bottom > 0) { reveal(node); return; }
      if (node.matches('figure,.gallery-item')) node.classList.add('reveal-image');
      // Stagger only small peer items, keeping the whole page responsive to scroll.
      if (node.matches('.credential-card,.service-tile')) node.style.setProperty('--reveal-delay', `${index%3*65}ms`);
      observer.observe(node);
      node.classList.add('reveal-pending');
    });
  } else targets.forEach(reveal);
  if ('IntersectionObserver' in window) {
    const banks = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) { entry.target.classList.add('is-bank-lit'); banks.unobserve(entry.target); }
      });
    }, {threshold:.15});
    document.querySelectorAll('[data-line-bank]').forEach(bank => banks.observe(bank));
  } else document.querySelectorAll('[data-line-bank]').forEach(bank => bank.classList.add('is-bank-lit'));
  document.addEventListener('focusin', event => {
    let node = event.target;
    while (node instanceof Element) {
      if (node.classList.contains('reveal-pending')) { reveal(node); observer?.unobserve(node); }
      node = node.parentElement;
    }
  });
  reduced.addEventListener('change', () => {
    if (reduced.matches) { observer?.disconnect(); targets.forEach(reveal); }
    requestDraw();
  });
  window.addEventListener('scroll', requestDraw, {passive:true});
  window.addEventListener('resize', updateHeaderSize, {passive:true});
  window.addEventListener('pageshow', requestDraw);
  if ('ResizeObserver' in window && header) new ResizeObserver(updateHeaderSize).observe(header);
  updateHeaderSize();
})();
