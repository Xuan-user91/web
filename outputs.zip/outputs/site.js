(() => {
  const menu = document.querySelector('#site-menu');
  const toggle = document.querySelector('.menu-toggle');
  const close = document.querySelector('.menu-close');
  if (!menu || !toggle || !close) return;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let closeTimer = 0, closing = null, resolveClosing = null, pendingNavigation = null;
  menu.classList.add('menu-motion');
  menu.querySelectorAll('.menu-nav>a').forEach((link,index) => link.style.setProperty('--menu-order', index));
  menu.querySelectorAll('.menu-aside>*').forEach((item,index) => item.style.setProperty('--menu-order', index));

  function restore() {
    clearTimeout(closeTimer);
    menu.classList.remove('is-menu-visible','is-menu-closing');
    document.body.classList.remove('menu-open');
    toggle.setAttribute('aria-expanded','false');
    toggle.focus({preventScroll:true});
    const resolve = resolveClosing;
    closing = resolveClosing = null;
    if (resolve) resolve();
  }
  function finishClose() {
    if (!closing) return;
    clearTimeout(closeTimer);
    if (typeof menu.close === 'function' && menu.open) menu.close();
    else { menu.removeAttribute('open'); restore(); }
  }
  function dismiss() {
    if (closing) return closing;
    if (!menu.hasAttribute('open')) return Promise.resolve();
    closing = new Promise(resolve => { resolveClosing = resolve; });
    const completion = closing;
    menu.classList.add('is-menu-closing');
    menu.classList.remove('is-menu-visible');
    if (reduced.matches) finishClose();
    else closeTimer = window.setTimeout(finishClose, 380);
    return completion;
  }
  toggle.addEventListener('click', () => {
    if (closing || menu.hasAttribute('open')) return;
    pendingNavigation = null;
    menu.classList.remove('is-menu-visible','is-menu-closing');
    document.body.classList.add('menu-open');
    toggle.setAttribute('aria-expanded','true');
    if (typeof menu.showModal === 'function') menu.showModal();
    else menu.setAttribute('open','');
    menu.scrollTop = 0;
    // Commit the initial transparent state before starting the CSS transitions.
    void menu.offsetWidth;
    menu.classList.add('is-menu-visible');
    close.focus({preventScroll:true});
  });
  close.addEventListener('click', dismiss);
  menu.addEventListener('cancel', event => { event.preventDefault(); dismiss(); });
  menu.addEventListener('close', restore);
  menu.addEventListener('transitionend', event => {
    if (event.target === menu && event.propertyName === 'opacity' && closing) finishClose();
  });
  menu.addEventListener('keydown', event => {
    if (event.key === 'Escape' && typeof menu.showModal !== 'function') {
      event.preventDefault(); dismiss();
    }
  });
  reduced.addEventListener('change', () => { if (reduced.matches && closing) finishClose(); });
  menu.querySelectorAll('a').forEach(link => link.addEventListener('click', event => {
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || link.hasAttribute('download') || (link.target && link.target !== '_self')) return;
    const target = new URL(link.href, location.href);
    // Delay only ordinary same-site navigation; phone/email keep native activation.
    if (['http:','https:','file:'].includes(target.protocol) && target.origin === location.origin) {
      event.preventDefault();
      if (pendingNavigation) return;
      pendingNavigation = target.href;
      dismiss().then(() => location.assign(target.href));
    } else dismiss();
  }));
})();

(() => {
  const viewer = document.querySelector('#photo-viewer');
  if (!viewer || typeof viewer.showModal !== 'function') return;
  const image = viewer.querySelector('img');
  const caption = viewer.querySelector('figcaption');
  const close = viewer.querySelector('.photo-close');
  let opener;
  document.querySelectorAll('[data-gallery]').forEach(link => {
    link.addEventListener('click', event => {
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      opener = link;
      image.src = link.href;
      image.alt = link.dataset.caption || link.querySelector('img')?.alt || '安装现场照片';
      caption.textContent = image.alt;
      viewer.showModal();
      document.body.classList.add('photo-open');
      close.focus({ preventScroll: true });
    });
  });
  close.addEventListener('click', () => viewer.close());
  viewer.addEventListener('click', event => { if (event.target === viewer) viewer.close(); });
  viewer.addEventListener('close', () => {
    document.body.classList.remove('photo-open');
    image.removeAttribute('src');
    opener?.focus({ preventScroll: true });
  });
})();

(() => {
  const filters = document.querySelector('.gallery-filters');
  const images = Array.from(document.querySelectorAll('.gallery-item'));
  const status = document.querySelector('[data-gallery-status]');
  if (!filters || !images.length) return;
  filters.hidden = false;
  filters.querySelectorAll('[data-filter]').forEach(button => {
    button.addEventListener('click', () => {
      const category = button.dataset.filter;
      let visible = 0;
      images.forEach(item => {
        item.hidden = category !== 'all' && item.dataset.category !== category;
        if (!item.hidden) visible++;
      });
      filters.querySelectorAll('button').forEach(other => {
        const selected = other === button;
        other.classList.toggle('is-active', selected);
        other.setAttribute('aria-pressed', String(selected));
      });
      if (status) status.textContent = `显示${category === 'all' ? '全部' : category}照片，共 ${visible} 张。`;
    });
  });
})();
