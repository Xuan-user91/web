(() => {
  const root = document.querySelector('[data-equipment-explorer]');
  if (!root) return;
  const svg = root.querySelector('svg');
  const parts = [...svg.querySelectorAll('[data-part]')];
  const slider = root.querySelector('input[type=range]');
  const output = root.querySelector('output');
  const play = root.querySelector('[data-equipment-play]');
  const status = root.querySelector('[data-equipment-status]');
  const guides = [...svg.querySelectorAll('[data-guide]')];
  const callouts = [...svg.querySelectorAll('[data-callout]')];
  const phase = root.querySelector('[data-equipment-phase]');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  const details = {
    all: '整体结构｜以纵向拉伸辊组为原型，分层呈现机械支撑、传动、电控与温控接口。点击分类可突出相应组件。',
    rollers: '精密辊系｜8 根示意辊筒逐根分离，呈现辊面、轴肩与轴颈。纵向拉伸设备通过辊系温度与速度控制处理薄膜，实际配置依设备工艺而定。',
    bearings: '轴承与端盖｜分别展示支承座、轴承环、端盖及固定件，便于理解轴系定位与连接关系。实际轴承形式及安装要求以设备文件为准。',
    drive: '独立传动｜4 组示意驱动分别展开电机、减速单元及联轴器。安装交接需关注轴线关系、连接状态及控制接口。',
    thermal: '温控接口｜分离呈现供回介质总管、阀组、仪表及连接软管。管路走向和温控分区为概念布置，具体按制造商设计执行。',
    frame: '机架与基座｜立柱、纵梁、横撑及 8 处调平支点分层展开，呈现辊系支承与设备基础之间的连接关系。',
    guard: '防护组件｜顶部框架与前侧透明防护面分离，展示罩体、支撑框和检修开口。动画仅表达结构层次。',
    electrical: '电控单元｜柜门、柜体及内部安装板独立展开，呈现电气组件和端接布置；不代表实际控制原理或接线图。'
  };
  let progress = 0, frame = 0, running = false, plan = null, elapsed = 0, last = 0;
  const track = document.querySelector('[data-equipment-scroll]');
  const hero = root.closest('.home-hero');
  const sticky = track?.querySelector('.equipment-sticky');
  const scrollUI = root.querySelector('[data-equipment-scroll-ui]');
  const chapterButtons = [...root.querySelectorAll('[data-scroll-equipment]')];
  const storyCopy = root.querySelector('[data-equipment-story-copy]');
  const storyTitle = root.querySelector('.equipment-caption strong');
  const chapters = [
    ['从系统，到每一处精密连接。', '从完整设备出发，逐层了解机械支撑、辊系及配套系统之间的连接关系。'],
    ['先看外围，再深入核心。', '防护与外围组件逐步分离，呈现检修空间、支撑框架和设备边界。'],
    ['让传动与接口，清晰衔接。', '驱动、轴承支承及温控接口依次展开，理解不同专业之间的连接关系。'],
    ['把精度，落实到辊系与基座。', '辊筒、轴系与基础分层呈现，关注设备定位、相对位置和装配基准。']
  ];
  let scrollEnabled = false, scrollFrame = 0, resizeFrame = 0, scrollTop = 0, chapter = -1;
  const smooth = x => x * x * (3 - 2 * x);
  const clamp = x => Math.max(0, Math.min(1, x));
  function draw(value) {
    progress = clamp(value);
    for (const part of parts) {
      const local = smooth(clamp((progress - Number(part.dataset.start)) / (Number(part.dataset.end) - Number(part.dataset.start))));
      part.setAttribute('transform', `translate(${Number(part.dataset.dx) * local} ${Number(part.dataset.dy) * local})`);
      // Film and lifting slings are contextual, not rigid detachable components.
      if (part.dataset.part === 'film') part.style.opacity = String(1 - smooth(clamp(progress * 3)));
    }
    for (const guide of guides) {
      const local = smooth(clamp((progress - Number(guide.dataset.start)) / (Number(guide.dataset.end) - Number(guide.dataset.start))));
      guide.setAttribute('x2', Number(guide.dataset.x) + Number(guide.dataset.dx) * local);
      guide.setAttribute('y2', Number(guide.dataset.y) + Number(guide.dataset.dy) * local);
    }
    svg.querySelector('[data-guides]').setAttribute('opacity', String(.36 * progress));
    svg.querySelector('[data-callouts]').setAttribute('opacity', String(smooth(clamp((progress - .85) / .15))));
    for (const label of callouts) label.setAttribute('transform', `translate(${Number(label.dataset.x) + Number(label.dataset.dx)} ${Number(label.dataset.y) + Number(label.dataset.dy)})`);
    // Pull back gradually to accommodate the outward-moving assemblies.
    const camera = smooth(progress);
    svg.setAttribute('viewBox', `${120 * (1-camera)} ${-40 - 130 * camera} ${1180 + 240 * camera} ${806 + 164 * camera}`);
    phase.textContent = progress < .01 ? '装配状态' : progress < .3 ? '01 / 外围组件分离' : progress < .7 ? '02 / 传动与接口展开' : progress < .99 ? '03 / 辊系与基座分层' : '完整爆炸视图';
    slider.value = String(Math.round(progress * 100));
    output.value = `${Math.round(progress * 100)}%`;
    if (scrollEnabled && !dialog.open) updateChapter();
    slider.setAttribute('aria-valuetext', `${Math.round(progress * 100)}%，${progress === 0 ? '装配状态' : progress === 1 ? '完全展开' : '展开中'}`);
  }
  function pause() {
    running = false;
    cancelAnimationFrame(frame);
    play.textContent = plan ? '继续播放' : progress > .99 ? '播放合拢' : '播放拆解';
  }
  function finish() {
    plan = null;
    pause();
    status.textContent = progress === 0 ? '已回到装配状态。' : '设备组件已展开，可选择部件查看说明。';
  }
  function tick(now) {
    if (!running || !plan) return;
    elapsed += Math.min(now - last, 80);
    last = now;
    let passed = 0;
    const step = plan.find(step => { if (elapsed <= passed + step.duration) return true; passed += step.duration; return false; });
    if (!step) { draw(plan[plan.length - 1].to); finish(); return; }
    draw(step.from + (step.to - step.from) * smooth(clamp((elapsed - passed) / step.duration)));
    frame = requestAnimationFrame(tick);
  }
  function resume() {
    running = true;
    last = performance.now();
    play.textContent = '暂停动画';
    frame = requestAnimationFrame(tick);
  }
  function animate(steps) {
    pause();
    if (reduced.matches) { draw(steps[steps.length - 1].to); finish(); return; }
    elapsed = 0;
    plan = steps;
    resume();
  }
  function clearSelection() {
    svg.classList.remove('is-selected');
    root.querySelectorAll('[data-select-part]').forEach(item => item.setAttribute('aria-pressed', String(item.dataset.selectPart === 'all')));
    root.querySelector('.equipment-part-description').textContent = details.all;
  }
  play.addEventListener('click', () => {
    clearSelection();
    if (running) { pause(); status.textContent = '动画已暂停。'; return; }
    if (plan) { resume(); return; }
    animate([{from:progress,to:progress > .99 ? 0 : 1,duration:6500}]);
  });
  root.querySelector('[data-equipment-explode]').addEventListener('click', () => { clearSelection(); animate([{from:progress,to:1,duration:4500}]); });
  root.querySelector('[data-equipment-reset]').addEventListener('click', () => { clearSelection(); animate([{from:progress,to:0,duration:4500}]); });
  root.querySelectorAll('[data-equipment-step]').forEach(button => button.addEventListener('click', () => {
    clearSelection(); animate([{from:progress,to:Number(button.dataset.equipmentStep)/100,duration:2200}]);
  }));
  slider.addEventListener('input', () => { pause(); plan = null; clearSelection(); draw(Number(slider.value) / 100); play.textContent = progress > .99 ? '播放合拢' : '播放拆解'; });
  root.querySelectorAll('[data-select-part]').forEach(button => button.addEventListener('click', () => {
    pause();
    const key = button.dataset.selectPart;
    svg.classList.toggle('is-selected', key !== 'all');
    parts.forEach(part => part.classList.toggle('is-highlighted', key === 'frame' ? ['frame','base'].includes(part.dataset.category) : part.dataset.category === key));
    root.querySelectorAll('[data-select-part]').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
    root.querySelector('.equipment-part-description').textContent = details[key];
  }));
  document.addEventListener('visibilitychange', () => { if (document.hidden && running) pause(); });
  reduced.addEventListener('change', () => { if (reduced.matches && running) pause(); });
  root.querySelector('.equipment-controls').hidden = false;
  const enlarge = root.querySelector('[data-equipment-enlarge]');
  const dialog = document.createElement('dialog');
  dialog.className = 'equipment-dialog';
  dialog.setAttribute('aria-label','薄膜设备爆炸视图放大展示');
  let marker;
  if (typeof dialog.showModal === 'function') {
    document.body.appendChild(dialog);
    enlarge.hidden = false;
    enlarge.addEventListener('click', () => {
        pause();
      if (dialog.open) { dialog.close(); return; }
      marker = document.createComment('equipment-view-position');
      root.before(marker);
      dialog.appendChild(root);
      enlarge.textContent = '关闭放大 ×';
      dialog.showModal();
      document.body.classList.add('equipment-open');
      enlarge.focus();
    });
    dialog.addEventListener('close', () => {
      pause();
      marker.replaceWith(root);
      document.body.classList.remove('equipment-open');
      enlarge.textContent = '放大查看 ↗';
      enlarge.focus({preventScroll:true});
      if (scrollEnabled) { clearSelection(); queueScroll(); }
    });
    dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  }
  function updateChapter() {
    root.style.setProperty('--equipment-progress', progress);
    const next = progress < .1 ? 0 : progress < .35 ? 1 : progress < .72 ? 2 : 3;
    if (next === chapter) return;
    chapter = next;
    storyTitle.textContent = chapters[next][0];
    storyCopy.textContent = chapters[next][1];
    chapterButtons.forEach((button, index) => {
      if (index === next) button.setAttribute('aria-current','step');
      else button.removeAttribute('aria-current');
    });
  }
  function readScroll() {
    scrollFrame = 0;
    if (!scrollEnabled || dialog.open) return;
    const rect = track.getBoundingClientRect();
    const distance = Math.max(1, track.offsetHeight - sticky.offsetHeight);
    const position = clamp((scrollTop - rect.top) / distance);
    // Brief assembled and exploded holds make the beginning and end readable.
    const value = clamp((position - .06) / .86);
    if (chapter < 0 || Math.abs(value - progress) > .00001) draw(value);
  }
  function queueScroll() {
    if (!scrollFrame) scrollFrame = requestAnimationFrame(readScroll);
  }
  function configureScroll() {
    resizeFrame = 0;
    if (!hero || !track || !sticky) return;
    scrollTop = Math.ceil(document.querySelector('.site-header')?.getBoundingClientRect().height || 0);
    const height = window.innerHeight - scrollTop;
    const enable = !reduced.matches && height >= 440 && CSS.supports('position','sticky');
    const wasEnabled = scrollEnabled;
    scrollEnabled = enable;
    hero.style.setProperty('--equipment-top', `${scrollTop}px`);
    hero.style.setProperty('--equipment-height', `${height}px`);
    hero.style.setProperty('--equipment-distance', `${Math.round(window.innerHeight * 2.15)}px`);
    hero.classList.toggle('is-equipment-scroll', enable);
    scrollUI.hidden = !enable;
    hero.classList.toggle('equipment-copy-static', hero.querySelector('.hero-copy').scrollHeight + 64 > height);
    if (enable) {
      if (!dialog.open) { pause(); plan = null; clearSelection(); queueScroll(); }
    } else if (wasEnabled) {
      chapter = -1;
      storyTitle.textContent = chapters[0][0];
      if (!dialog.open) { pause(); plan = null; draw(0); }
    }
  }
  chapterButtons.forEach(button => button.addEventListener('click', () => {
    if (!scrollEnabled) return;
    const target = Number(button.dataset.scrollEquipment);
    const distance = Math.max(1, track.offsetHeight - sticky.offsetHeight);
    const top = window.scrollY + track.getBoundingClientRect().top - scrollTop + distance * (.06 + target * .86);
    window.scrollTo({top, behavior:'smooth'});
  }));
  root.querySelector('[data-equipment-skip]').addEventListener('click', event => {
    const next = document.getElementById('company-overview');
    if (!next) return;
    event.preventDefault();
    next.focus({preventScroll:true});
    window.scrollTo({top:window.scrollY + next.getBoundingClientRect().top - scrollTop,behavior:'instant'});
  });
  window.addEventListener('scroll', queueScroll, {passive:true});
  window.addEventListener('resize', () => {
    if (!resizeFrame) resizeFrame = requestAnimationFrame(configureScroll);
  }, {passive:true});
  window.addEventListener('pageshow', queueScroll);
  reduced.addEventListener('change', configureScroll);
  draw(0);
  configureScroll();
  if (document.fonts?.ready) document.fonts.ready.then(configureScroll);
})();
