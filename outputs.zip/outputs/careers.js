(() => {
  const button = document.querySelector('[data-copy-target]');
  const status = document.querySelector('#copy-introduction-status');
  if (!button || !status) return;
  const copyViaSelection = (text) => {
    const field = document.createElement('textarea');
    field.value = text;
    field.setAttribute('readonly', '');
    field.style.cssText = 'position:fixed;left:-9999px;top:0;';
    document.body.appendChild(field);
    field.select();
    let copied = false;
    try { copied = document.execCommand('copy'); } catch (_) { /* Use manual selection below. */ }
    field.remove();
    button.focus({ preventScroll: true });
    return copied;
  };
  button.addEventListener('click', async () => {
    const target = document.getElementById(button.dataset.copyTarget);
    if (!target) return;
    const text = target.textContent.trim();
    let copied = false;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        copied = true;
      }
    } catch (_) { /* Local previews can restrict clipboard access. */ }
    if (!copied) copied = copyViaSelection(text);
    if (copied) {
      status.textContent = '已复制。替换括号内的信息后，即可用于微信自我介绍。';
    } else {
      const range = document.createRange();
      range.selectNodeContents(target);
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      status.textContent = '未能自动复制，已选中模板文字，请手动复制。';
    }
  });
})();
