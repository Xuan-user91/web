(() => {
  const story = document.querySelector('[data-motion-story]');
  if (!story) return;
  const sticky = story.querySelector('.motion-sticky');
  const panels = [...story.querySelectorAll('[data-motion-panel]')];
  const buttons = [...story.querySelectorAll('[data-motion-go]')];
  const nav = story.querySelector('.motion-navigation');
  const track = story.querySelector('.motion-track');
  const hint = story.querySelector('.motion-scroll-hint');
  const scene = story.querySelector('[data-scene]');
  const readRange = node => node.split(',').map(Number);
  const drawPaths = scene ? [...scene.querySelectorAll('[data-scene-draw]')].map(el => ({el,range:readRange(el.dataset.sceneDraw)})) : [];
  const reveals = scene ? [...scene.querySelectorAll('[data-scene-reveal]')].map(el => ({el,range:readRange(el.dataset.sceneReveal)})) : [];
  const movements = scene ? [...scene.querySelectorAll('[data-scene-translate]')].map(el => ({el,values:readRange(el.dataset.sceneTranslate)})) : [];
  const focusGroups = scene ? [...scene.querySelectorAll('[data-scene-focus]')] : [];
  const lineUnits = scene ? [...scene.querySelectorAll('[data-line-unit]')].map(el => ({el,values:readRange(el.dataset.lineUnit)})) : [];
  const scans = scene ? [...scene.querySelectorAll('[data-bank-scan]')] : [];
  const spins = scene ? [...scene.querySelectorAll('[data-scene-spin]')].map(el => ({el,values:readRange(el.dataset.sceneSpin)})) : [];
  const flights = scene ? [...scene.querySelectorAll('[data-flight-path]')].map(el => {
    const path = document.getElementById(el.dataset.flightPath);
    return {el,path,length:0,range:readRange(el.dataset.flightRange)};
  }) : [];
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const short = matchMedia(scene ? '(max-height: 579px)' : '(max-height: 699px)');
  let enabled = false, scheduled = false, previous = -1, top = 80;
  const clamp = value => Math.min(1, Math.max(0, value));
  const ease = value => value * value * (3 - 2 * value);
  const rangeProgress = (value, start, end) => end <= start ? 1 : ease(clamp((value - start) / (end - start)));
  function drawScene(progress, staticMode = false) {
    if (!scene) return;
    drawPaths.forEach(({el,range}) => {
      el.style.strokeDasharray = '1';
      el.style.strokeDashoffset = String(1 - rangeProgress(progress,...range));
    });
    reveals.forEach(({el,range}) => {el.style.opacity = String(rangeProgress(progress,...range));});
    movements.forEach(({el,values:[x0,y0,x1,y1,start,end]}) => {
      const t = rangeProgress(progress,start,end);
      el.setAttribute('transform',`translate(${x0+(x1-x0)*t} ${y0+(y1-y0)*t})`);
    });
    focusGroups.forEach(el => {
      const proximity = clamp(1 - Math.abs(Number(el.dataset.sceneFocus)-progress*2));
      el.style.opacity = String(staticMode ? 1 : .28 + .72*ease(proximity));
    });
    // The banks represent project scope, never live machine status.
    lineUnits.forEach(({el,values:[bank,index,count]}) => {
      const start = [0,.25,.75][bank];
      const end = [.22,.70,1][bank];
      const local = clamp((progress-start)/(end-start));
      const lit = rangeProgress(local, index/(count+1), (index+1)/(count+1));
      el.style.opacity = String(staticMode ? 1 : .2 + .8*lit);
    });
    scans.forEach(el => {
      const bank = Number(el.dataset.bankScan);
      const local = (progress-[0,.25,.75][bank])/([.22,.70,1][bank]-[0,.25,.75][bank]);
      el.setAttribute('transform',`translate(${65+540*clamp(local)} 0)`);
      el.style.opacity = String(!staticMode && local>0 && local<1 ? .9 : 0);
    });
    spins.forEach(({el,values:[x,y,angle]}) => el.setAttribute('transform',`rotate(${angle*progress} ${x} ${y})`));
    flights.forEach(({el,path,length,range:[start,end]}) => {
      if (!length) { el.style.opacity = '0'; return; }
      const t = rangeProgress(progress,start,end);
      const point = path.getPointAtLength(length*t);
      const previousPoint = path.getPointAtLength(Math.max(0,length*t-1));
      const nextPoint = path.getPointAtLength(Math.min(length,length*t+1));
      const angle = Math.atan2(nextPoint.y-previousPoint.y,nextPoint.x-previousPoint.x)*180/Math.PI;
      el.setAttribute('transform',`translate(${point.x} ${point.y}) rotate(${angle})`);
      el.style.opacity = String(!staticMode && t>0 && t<1 ? Math.min(1,t*12,(1-t)*12) : 0);
    });
  }
  function draw() {
    scheduled = false;
    if (!enabled) return;
    const rect = story.getBoundingClientRect();
    const distance = Math.max(1, story.offsetHeight - sticky.offsetHeight);
    const progress = clamp((top - rect.top) / distance);
    const chapter = progress * (panels.length - 1);
    let current = Math.round(chapter);
    // Keep an actively focused chapter's link available until focus moves out.
    const focused = panels.findIndex(panel => panel.contains(document.activeElement));
    const visibleChapter = focused >= 0 ? focused : chapter;
    if (focused >= 0) current = focused;
    drawScene(visibleChapter / (panels.length - 1));
    story.style.setProperty('--story-progress', String((visibleChapter + 1) / panels.length));
    panels.forEach((panel, i) => {
      const delta = i - visibleChapter;
      const weight = clamp(1 - Math.abs(delta) * (scene ? 2 : 1));
      const opacity = weight * weight * (3 - 2 * weight);
      panel.style.setProperty('--panel-distance', String(delta));
      panel.style.setProperty('--panel-opacity', String(opacity));
      panel.style.setProperty('--visual-scale', String(1 - Math.min(1,Math.abs(delta)) * .12));
      panel.style.setProperty('--photo-scale', String(1.06 + visibleChapter * .025));
      panel.style.setProperty('--line-offset', String(1100 * (1 - weight)));
      panel.style.visibility = opacity > .001 ? 'visible' : 'hidden';
      panel.classList.toggle('is-current', current === i);
      panel.inert = current !== i;
      panel.setAttribute('aria-hidden', String(current !== i));
    });
    if (previous !== current) {
      buttons.forEach((button, i) => button.setAttribute('aria-pressed', String(i === current)));
      previous = current;
    }
  }
  function requestDraw() {
    if (!scheduled) { scheduled = true; requestAnimationFrame(draw); }
  }
  function configure() {
    top = Math.ceil(document.querySelector('.site-header')?.getBoundingClientRect().height || 80);
    story.style.setProperty('--motion-top', `${top}px`);
    // Small landscape windows and reduced-motion preferences retain full static chapters.
    enabled = !reduced.matches && !short.matches;
    story.classList.toggle('is-scroll-ready', enabled);
    if (scene) {
      story.classList.add('has-shared-scene');
      scene.hidden = false;
      flights.forEach(flight => {
        try { flight.length = flight.path.getTotalLength(); }
        catch (_) { flight.length = 0; }
      });
      if (!enabled) drawScene(1, true);
    }
    nav.hidden = track.hidden = hint.hidden = !enabled;
    if (!enabled) panels.forEach(panel => {
      panel.removeAttribute('style'); panel.inert = false; panel.removeAttribute('aria-hidden'); panel.classList.remove('is-current');
    });
    previous = -1;
    requestDraw();
  }
  buttons.forEach((button, i) => button.addEventListener('click', () => {
    if (!enabled) return;
    const start = scrollY + story.getBoundingClientRect().top - top;
    const range = Math.max(1, story.offsetHeight - sticky.offsetHeight);
    window.scrollTo({top:start + range * i / (panels.length - 1),behavior:'smooth'});
  }));
  window.addEventListener('scroll', requestDraw, {passive:true});
  window.addEventListener('resize', configure, {passive:true});
  story.addEventListener('focusout', requestDraw);
  reduced.addEventListener('change', configure);
  short.addEventListener('change', configure);
  configure();
})();
