(() => {
  const form = document.querySelector('#assessment-form');
  const draft = document.querySelector('#consultation-draft');
  if (!form || !draft) return;
  const preview = document.querySelector('#draft-content');
  const emailLink = document.querySelector('#draft-email');
  const download = document.querySelector('#draft-download');
  const heading = document.querySelector('#draft-title');
  const fields = [
    ['enquiry-name', '联系人'],
    ['enquiry-contact', '联系方式'],
    ['enquiry-company', '公司名称'],
    ['enquiry-location', '项目地点'],
    ['enquiry-equipment', '产线或设备类型'],
    ['enquiry-stage', '项目阶段'],
    ['enquiry-brief', '项目条件与评估需求']
  ];
  let content = '';
  const clearDraft = () => {
    content = '';
    preview.value = '';
    draft.hidden = true;
    emailLink.href = 'mailto:825515458@qq.com';
  };
  form.addEventListener('input', event => {
    if (typeof event.target.setCustomValidity === 'function') event.target.setCustomValidity('');
    clearDraft();
  });
  form.addEventListener('reset', clearDraft);
  form.addEventListener('submit', event => {
    event.preventDefault();
    form.querySelectorAll('[required]').forEach(field => {
      field.setCustomValidity(field.value.trim() ? '' : '请填写此项。');
    });
    if (!form.reportValidity()) return;
    const lines = fields.map(([id, label]) => {
      const value = document.getElementById(id).value.trim();
      return `${label}：${value || '待沟通'}`;
    });
    content = ['盛云团队您好：', '', '希望就以下项目申请技术可行性评估。', '', ...lines, '', '设备清单、图纸或现场资料可在邮件中另附。'].join('\n');
    preview.value = content;
    const subject = '薄膜产线技术可行性评估咨询';
    emailLink.href = `mailto:825515458@qq.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(content)}`;
    draft.hidden = false;
    heading.focus();
  });
  download.addEventListener('click', () => {
    if (!content) return;
    const blob = new Blob(['\uFEFF', content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = '盛云-项目技术评估咨询.txt';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
})();
